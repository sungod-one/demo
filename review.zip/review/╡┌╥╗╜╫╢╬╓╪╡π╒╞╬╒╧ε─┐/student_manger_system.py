'''
    学生管理系统
    项目计划：
    数据模型类：StudentModel
        数据：编号 id,姓名 name,年龄 age,成绩 score
    逻辑控制类：StudentManagerController
        数据：学生列表 __stu_list
        行为：获取列表 stu_list,添加学生 add_student，删除学生remove_student，修改学生update_student，根据成绩排序order_by_score。
    界面视图类：StudentManagerView
        数据：逻辑控制对象__manager
        行为：显示菜单__display_menu，选择菜单项__select_menu_item，入口逻辑main，
        输入学生__input_students，输出学生__output_students，删除学生__delete_student，修改学生信息__modify_student，按成绩输出学生__output_student_by_score
        _________________________________14:30_____________________________________________
'''


class StudentModel:
    '''
        学生信息模型
    '''

    def __init__(self, name="", age=0, score=0, id=0):
        '''
            创建学生对象
        :param name: 姓名  str类型
        :param age: 年龄  int类型
        :param score: 成绩  float类型
        :param id: 编号（该学生对象的唯一标识）
        '''
        self.name = name
        self.age = age
        self.score = score
        self.id = id


class StudentMangerController:
    '''
        学生管理控制器，负责业务逻辑处理
    '''
    __init_id = 0  # 类变量，初始编号，被所有对象共享

    def __init__(self):
        self.__student_list = []

    @property
    def student_list(self):
        '''
            学生列表
        :return: 学生信息的列表
        '''
        return self.__student_list

    def add_student(self, stu_info):
        '''
            添加一个新学生
        :param stu_info: 没有编号的学生信息
        '''
        stu_info.id = self.__generate_id()
        self.__student_list.append(stu_info)

    def __generate_id(self):
        '''
            生成学生id
        :return: 返回学生id值
        '''
        StudentMangerController.__init_id += 1
        return StudentMangerController.__init_id

    def remove_student(self, stu_id):
        '''
            删除学生信息
        :param stu_id: 学生id，用于删除指定信息
        '''
        for item in self.__student_list:
            if item.id == stu_id:
                self.__student_list.remove(item)
                return True  # 移除成功
        return False  # 移除失败

    def updata_student(self, stu_info):
        '''
            修改学生信息
        :param stu_info: 学生信息
        :return: 修改成功返回True，修改失败返回Flase
        '''
        for item in range(len(self.__student_list)):
            if self.__student_list[item].id == stu_info.id:
                self.__student_list[item] = stu_info
                return True
        return False

    def order_by_score(self):
        '''
            按照成绩升序排列
        :return: 排列后的列表
        '''
        list01 = self.__student_list[::]
        for item in range(len(list01) - 1):
            for items in range(item + 1, len(list01)):
                if list01[item].score > list01[items].score:
                     list01[item], list01[items] = list01[items], list01[item]
        return list01


class StudentManagerView:
    '''
        学生管理器视图
    '''

    def __init__(self):
        '''
            创建控制器的实例变量
        '''
        self.__manger = StudentMangerController()

    def __display_menu(self):
        '''
            显示菜单
        '''
        print("1)添加学生")
        print("2)显示学生")
        print("3)删除学生")
        print("4)修改学生")
        print("5)成绩按升序排列")

    def __select_menu(self):
        '''
            菜单选择
        '''
        item = int(input("请输入："))
        if item == 1:
            self.__input_student()
        elif item == 2:
            self.__output_students(self.__manger.student_list)
        elif item == 3:
            self.__delete_student()
        elif item == 4:
            self.__modify_student()
        else:
            self.__output_student_by_score()

    def main(self):
        '''
            主函数
        '''
        while True:
            self.__display_menu()
            self.__select_menu()

    def __input_student(self):
        '''
            添加学生信息
        '''
        name = input("请输入姓名:")
        age = int(input("请输入年龄:"))
        score = int(input("请输入成绩:"))
        stu = StudentModel(name, age, score)
        self.__manger.add_student(stu)

    def __output_students(self, list_info):
        '''
            输出学生信息
        :param list_info:学生信息的列表
        '''
        for item in list_info:
            print(item.id, item.name, item.age, item.score)

    def __delete_student(self):
        '''
            删除学生信息
        '''
        stu_id = int(input("请输入要删除学生的id:"))
        if self.__manger.remove_student(stu_id):
            print("移除成功！")
        else:
            print("移除失败")

    def __modify_student(self):
        '''
            修改学生信息
        '''
        stu_id = int(input("请输入要修改学生id:"))
        stu_name = input("请输入修改后的姓名:")
        stu_age = int(input("请输入修改后的年龄:"))
        stu_score = int(input("请输入修改后的成绩:"))
        modify_info = StudentModel(stu_name, stu_age, stu_score, stu_id)
        if self.__manger.updata_student(modify_info):
            print("修改信息成功！")
        else:
            print("修改信息失败！")

    def __output_student_by_score(self):
        '''
            按照学生成绩升序排列输出学生信息
        '''
        list_stu_info = self.__manger.order_by_score()
        self.__output_students(list_stu_info)


view = StudentManagerView()
view.main()
