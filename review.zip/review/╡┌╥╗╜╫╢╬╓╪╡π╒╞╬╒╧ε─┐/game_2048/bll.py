'''
    游戏逻辑控制器，负责处理游戏核心算法
'''
from model import DirectionModel
from model import Location
import random


class GameCoreController:

    def __init__(self):
        self.__list_merge = None
        self.__map = [
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0],
            [0, 0, 0, 0]
        ]
        self.list_empty_location = []

    @property
    def map(self):
        return self.__map

    def __zero_to_end(self):
        # 从后向前，如果发现零元素删除，并追加
        '''
        零元素移动到末尾
        :param list_merge:
        :return:
        '''
        for i in range(len(self.__list_merge) - 1, -1, -1):
            if self.__list_merge[i] == 0:
                del self.__list_merge[i]
                self.__list_merge.append(0)

    def __same_number_merge(self):
        # 先将中间的零元素移到末尾
        # 再合并相邻相同元素
        self.__zero_to_end()
        for item in range(len(self.__list_merge) - 1):
            if self.__list_merge[item] == self.__list_merge[item + 1]:
                # 将后一个累加前一个之上
                self.__list_merge[item] *= 2
                del self.__list_merge[item + 1]
                self.__list_merge.append(0)

    def __map_left_move(self):
        '''
        向左移动
        '''
        # 将二维列表中每行交给merge执行
        for item in self.__map:
            self.__list_merge = item
            self.__same_number_merge()

    def __map_right_move(self):
        '''
        向右移动
        '''
        # 将二维列表中每行（从右向左）交给merge执行
        for line in self.__map:
            # 从右向左取出数据 形成 新列表
            self.__list_merge = line[::-1]
            self.__same_number_merge()
            # 从右向左接受 合并后的数据
            # 通过切片定位列表元素，没有产生新列表
            line[::-1] = self.__list_merge

    def __move_down(self):
        self.__transpose()
        self.__map_right_move()
        self.__transpose()

    def __move_up(self):
        self.__transpose()
        self.__map_left_move()
        self.__transpose()

    def __transpose(self):
        for line in range(len(self.__map)):
            for item in range(line + 1, len(self.__map)):
                self.__map[line][item], self.__map[item][line] = self.__map[item][line], self.__map[line][item]

    def move(self, dir):
        '''
            移动
        :param dir:方向 DirectionModel类型
        :return:
        '''
        if dir == DirectionModel.UP:
            self.__move_up()
        elif dir == DirectionModel.DOWN:
            self.__move_down()
        elif dir == DirectionModel.LEFT:
            self.__map_left_move()
        elif dir == DirectionModel.RIGHT:
            self.__map_right_move()

    def get_random(self):
        '''
        对二维数组中数据为0的随机位置添加为2（90%概率）或4（10%概率）
        :return:
        '''
        self.__get_empty_location()
        if len(self.list_empty_location) == 0:
            return
        location = random.choice(self.list_empty_location)
        self.__map[location.r_index][location.c_index] = 2 if random.randint(1, 10) > 1 else 4
        self.list_empty_location.remove(location)

    def __get_empty_location(self):
        '''
        获取空白位置
        :return:
        '''
        self.list_empty_location.clear()
        for line in range(len(self.__map)):
            for item in range(len(self.__map[line])):
                if self.__map[line][item] == 0:
                    self.list_empty_location.append(Location(line, item))

    def is_gameover(self):
        '''
        游戏是否结束
        :return:
        '''
        if len(self.list_empty_location) > 0:
            return False
        for item in range(len(self.__map)):
            for line in range(len(self.__map[item]) - 1):
                if self.__map[item][line] == self.__map[item][line + 1] or self.__map[item][line] == \
                        self.__map[item + 1][line]:
                    return False
        return True


# -----------------测试代码-------------------------
if __name__ == '__main__':
    controller = GameCoreController()
    print(controller.map)
    controller.get_random()
    print(controller.map)
