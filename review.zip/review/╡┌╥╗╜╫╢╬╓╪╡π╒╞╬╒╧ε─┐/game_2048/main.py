from ui import GameConsoleView

if __name__ == '__main__':
    view = GameConsoleView()
    view.main()
