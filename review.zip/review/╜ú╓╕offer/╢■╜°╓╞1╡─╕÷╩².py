# a = -5
# b = bin(~a)
# print(8 - b.count('1'))
# print(bin(a))


# class Solution:
#     def NumberOf1(self, n):
#         return sum([(n >> i & 1) for i in range(0, 32)])
#
#
# a = Solution()
# print(a.NumberOf1(5))


def sum(a):
    if a == 1:
        return 1
    return a + sum(a-1)

print(sum(100))