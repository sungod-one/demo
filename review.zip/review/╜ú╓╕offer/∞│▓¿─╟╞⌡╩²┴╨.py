"""
大家都知道斐波那契数列，现在要求输入一个整数n，请你输出斐波那契数列的第n项（从0开始，第0项为0）。
"""


def fib_sequence(n):
    if n == 0:
        return 0
    elif n == 1:
        return 1
    else:
        return fib_sequence(n - 1) + fib_sequence(n - 2)


print(fib_sequence(6))

# 非递归算法
"""
def Fibonacci(self, n):
        if n==0:
            return 0
        elif n==1:
            return 1
        else:
            a,b = 0,1
            while n>1:
                a,b = b,a+b
                n=n-1
            return b
"""