"""
输入某二叉树的前序遍历和中序遍历的结果，请重建出该二叉树。假设输入的前序遍历和中序遍历的结果中都不含重复的数字。
例如输入前序遍历序列{1,2,4,7,3,5,6,8}和中序遍历序列{4,7,2,1,5,3,8,6}，则重建二叉树并返回。
"""


class etree:
    def __init__(self, val, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right


class reblud_etree:

    def reConstructBinaryTree(self, pre, tin):
        if not len(tin):
            return None
        root = etree(pre[0])
        root.left = self.reConstructBinaryTree(pre[1:tin.index(pre[0]) + 1], tin[:tin.index(pre[0])])
        root.right = self.reConstructBinaryTree(pre[tin.index(pre[0]) + 1:], tin[tin.index(pre[0]) + 1:])

        return root

    def for_etree(self, root):
        if root is None:
            return
        self.for_etree(root.left)
        print(root.val)
        self.for_etree(root.right)


if __name__ == '__main__':
    list_pre = [1, 2, 4, 7, 3, 5, 6, 8]
    list_tin = [4, 2, 7, 1, 5, 3, 8, 6]
    re = reblud_etree()
    root = re.reConstructBinaryTree(list_pre, list_tin)
    re.for_etree(root)
