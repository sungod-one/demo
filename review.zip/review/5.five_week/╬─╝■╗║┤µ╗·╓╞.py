"""
buffering.py
文件读写缓冲机制演示
缓冲刷新条件：
１．缓冲区满了
２．行缓冲换行是会自动刷新
３．程序运行结束或者文件close()关闭
４．调用flush()函数
"""

f = open("test", "w", 1)  # １表示行缓冲
while True:
    data = input(">>")
    if not data:
        break
    f.write(data)
    f.flush()  # 刷新缓冲
f.close()
