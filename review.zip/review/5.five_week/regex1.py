"""
regex1.py re模块功能函数演示２
生成ｍａｔｃｈ对象的函数
"""
import re

s = "今年是2019年,建国70周年"
pattern = r"\d+"

# 返回迭代对象
it = re.finditer(pattern, s)
for item in it:
    print(item.group())  # 获取match对象对应的内容

# 完全匹配一个字符串 (匹配条件要完全符合全部字符串)
m = re.fullmatch(r"[,\w]+", s)
print(m.group())

# 匹配目标字符串的开始位置
m = re.match(r"\w+?", s)
print(m.group())

# 匹配第一处符合正则表达式的内容
m = re.search(r"\d+", s)
print(m.group())

"""
import re
pattern = r"(ab)cd(?P<pig>ef)"
regex = re.compile(pattern)
obj = regex.search("abcdefghi", 0, 8)


# 属性变量
print(obj.pos)  # 目标字符串开始位置
print(obj.endpos)  # 目标字符串结束位置
print(obj.re)  # 正则
print(obj.string)  # 目标字符串
print(obj.lastgroup)  # 最后一组组名
print(obj.lastindex)  # 最后一组序列号

print("==============================================")
# 属性方法
print(obj.span())  # 匹配内容在字符串中的位置
print(obj.start())
print(obj.end())
print(obj.groupdict())  # 生成捕获组字典
print(obj.groups())  # 子组对应内容元组
print(obj.group())  # 获取match对应内容
print(obj.group("pig"))
"""

"""
import re

# 目标字符串
s = "Alex:1994,Sunny:1996"

pattern = r"(\w+):(\d+)"  # 正则表达式

# re模块调用findall
l = re.findall(pattern, s)
print(l)


# compile 对象调用findall
regex = re.compile(pattern)
l = regex.findall(s, 0, 12)
print(l)

# 按照正则表达式匹配内容切割字符串
l = re.split(r"[:,]", s)
print(l)

# 替换目标字符串
# s = re.sub(r":", "-", s, 1)
# print(s)

# 替换目标字符串
s = re.subn(r":", "-", s, 1)
print(s)
"""
