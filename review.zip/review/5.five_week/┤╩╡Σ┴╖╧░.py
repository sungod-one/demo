"""
从终端输入一个单词
从单词本中找到该单词，打印解释内容
如果找不到则打印“找不到”
"""
f = open("dict.txt","r")
temp = input("请输入单词：")
# while True:
#     temp2 = f.readline()
#     list01 = temp2.split("   ")
#     if temp == list01[0]:
#         print(list01[0],list01[-1])
#         break
#     if not temp2:
#         print("没找到单词！")
#         break
#
for line in f:
    w = line.split(" ")[0]
    if w > temp:
        print("没找到单词！")
    elif temp == w:
        print(line)
        break
else:
    print("没找到单词！")
f.close()