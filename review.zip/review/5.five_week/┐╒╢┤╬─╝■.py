"""
空洞文件 可以用于视频下载预留足够空间
"""
f = open("test", "wb")
f.write(b"start")
f.seek(1024 * 1024, 2)  # 从结尾向后移动１ｋ字节
f.write(b"end")
f.close()
