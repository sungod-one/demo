'''
经理：曹操,刘备,孙权
技术：曹操,刘备,张飞,关羽
请计算：
是经理也是技术的有谁
是经理不是技术的有谁
是技术不是经理的有谁
张飞是经理吗
身兼一职的都有谁
经理和技术总工有多少人
'''
set_manager = {"曹操", "刘备", "孙权"}
set_technology = {"曹操", "刘备", "张飞", "关羽"}
print("经理也是技术的有:", set_manager & set_technology)
print("是经理不是技术的有:", set_manager - set_technology)
print("是技术不是经理的有:", set_technology - set_manager)
print("张飞是经理:", "张飞" in set_manager)
print("身兼一职的都有:", set_manager ^ set_technology)
print("经理和技术总工有多少人:", len(set_manager | set_technology))