'''
矩阵装置 将二维列表的列，变成行，形成一个新列表
第一列变成第一行
'''
import copy
import numpy as np
list01 = [
    [1, 2, 3, 4],
    [5, 6, 7, 8, ],
    [9, 10, 11, 12],
    [13, 14, 15, 16]
]
list02 = []
for item in range(len(list01)):
    line = []
    list02.append(line)
    for item1 in range(len(list01[item])):
        line.append(list01[item1][item])
print(list02)

list03 = []
for item in range(len(list01)):
    list03.append([])
    for item1 in range(len(list01[item])):
        list03[item].append(list01[item1][item])
print(list03)


list04 = copy.deepcopy(list01)
for item in range(len(list01)):
    for item1 in range(len(list01[item])):
        list04[item1][item] = list01[item][item1]
print(list04)

list05 = copy.deepcopy(list01)
print('*'*50)
print(list05)
for line in range(len(list05) - 1):
    for item in range(line+1, len(list05[line])):
        list05[line][item], list05[item][line] = list05[item][line], list05[line][item]

print(list05)

a = np.array(list01)
b = a.T
b = b.tolist()  # 把ndarray对象转为列表对象
print(b)