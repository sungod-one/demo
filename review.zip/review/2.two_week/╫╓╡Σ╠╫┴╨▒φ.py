'''
字典内嵌套列表
{"张无忌":[28,100,"男"]}

字典内嵌套字典
{"张无忌":{"age"=28,"score"=100,"sex"="男"}}

列表内嵌套字典
[{"name"="张无忌","age"=28,"score"=100,"sex"="男"}]

选择策略：根据具体需求，结合优缺点，综合考虑（两害相权取其轻）
    字典：
        优点：根据键获取值，读取速度快；
             代码可读性相对列表更高（根据键获取与根据索引获取）
        缺点：内存占用大；获取值只能根据键，不灵活
    列表：
        优点：根据索引/切片，获取元素更灵活
              相比字典占内存更小、
        缺点：通过索引获取，如果信息较多，可读性不高；速度比字典稍慢
'''
# 在控制台中录入多个人的多个喜好
# 例如：请输入姓名
#      请输入第一个喜好
#      请输入第二个喜好
#      请输入第三个喜好
#      请输入第四个喜好
#      。。。。
#      请输入姓名
#      。。。。。
#      输入空字符停止
#      最后在控制台中打印所有人的所有喜好

dict_info = {}
while True:
    count = 1
    list_hobby = []
    name = input("请输入姓名：")
    if name is '':
        break
    while True:
        hobby = input("请输入第%d个喜好：" % count)
        if hobby is '':
            break
        else:
            list_hobby.append(hobby)
            count += 1
    dict_info[name] = list_hobby
for name_key, list_hobby_value in dict_info.items():
    print("%s的爱好有：" % name_key, end="")
    for a in list_hobby_value:
        print(a+'', end=' ')
    print()
