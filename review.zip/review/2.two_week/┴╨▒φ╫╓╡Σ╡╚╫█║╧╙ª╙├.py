list01 = ["无忌", "赵敏", "周芷若"]
list02 = [101, 102, 103]
dict01 = {item: len(item) for item in list01}
print(dict01)
dict02 = {key: value for key, value in zip(list01, list02)}
print(dict02)
dict03 = {list01[item]: list02[item] for item in range(len(list02))}
print(dict03)

# 需求：根据值找键怎么办
# 解决方案一：键值互换
dict02 = {value: key for key, value in dict01.items()}
print(dict02)
# 缺点：如果键重复，交换后则丢失数据
# 如果需要保持所有数据
# 解决方案二：
list05 = [(value, key) for key, value in dict01.items()]
print(list05)
print(list05[0][1])
# 解决方案三
print(dict01)
list06 = [key for key,value in dict01.items() if value == 2]
print(list06)