class ICBC:
    '''
        工商银行
    '''
    # 表示总行的钱
    total_money = 1000000
    # 因为类方法没有对象地址self，类方法不能访问实例成员
    @classmethod
    def print_total_money(cls):
        print("总行还有多少钱%d" % ICBC.total_money)

    def __init__(self, name, money):
        self.name = name
        self.money = money
        ICBC.total_money -= money


i01 = ICBC("广梁门支行", 100000)
i02 = ICBC("陶然亭支行", 100000)
print("总行还有多少钱%d" % ICBC.total_money)
# 通过类名调用类方法，会自动将类名传入类方法
ICBC.print_total_money()
list01 = ["你好"]
str01 = ''.join(list01).encode("utf-8")
print(str01)
