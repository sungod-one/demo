'''
    字典
'''
# 1.如何创建
# 空
dict01 = {}
dict01 = dict()

# 默认值
dict01 = {"wj": 100, "zm": 80, "zr": 90}
print(dict01)
dict01 = dict([("a", "b"), ("c", "d")])
print(dict01)

# 2.查找(根据key查找值)
print(dict01["a"])
# 如果key不存在时会出错,所以一般加一个判断
if "qtx" in dict01:
    print(dict01["qtx"])

# 3.修改元素（之前存在key）
dict01["a"] = "BB"
print(dict01)

# 4.添加（之前不存在key）
dict01["e"] = "f"
print(dict01)

# 5.删除
del dict01["a"]
print(dict01)

# 6.遍历（获取字典中所有元素）
# 只获取键
for key in dict01:
    print(key)
    print(dict01[key])
# 只获取值
for value in dict01.values():
    print(value)
# 获取键和值
for key, value in dict01.items():
    print(key, value)

