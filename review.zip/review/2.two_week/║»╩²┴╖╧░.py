'''
day08
1. 三合一
2. 当天练习独立完成
3. 自学(参照菜鸟教程)字符串/列表/字典常用函数(方法),实现如下功能。
    字符串："　校　训：自　强不息、厚德载物。　　"
    查找空格的数量
    删除字符串前后空格
    删除字符串所有空格
    查找"载物"的位置
    判断字符串是否以"校训"开头.
4. 定义函数，计算指定范围内的素数
5. 群讨论：is  与 == 的区别
a = [1,2]
b = [1,2]
print(a is b)
print(a == b)
6. 玩2048游戏(了解游戏规则).
7. 重构 shopping.py 程序
   不改变原有功能，修改程序代码。
8. 阅读:python入门到实践第8章
'''
str01 = " 校 训:自 强不息、厚德载物。  "
print(str01.count(' '))
print(str01.strip())
print(str01.replace(" ", ''))
print(str01.find("载物"))
print(str01.startswith("校训"))
print(str01)


def is_prime(number):
    for item in range(2, number):
        if number % item is 0:
            return False
    return True


def get_prime(begin, end):
    list_result = []
    for number in range(begin, end + 1):
        if is_prime(number):
            list_result.append(number)
    return list_result


print(get_prime(1, 10))
