'''
    练习：定义对象计数器
    定义老婆类，创建3个老婆对象
    可以通过类变量记录老婆对象个数
    可以通过类方法打印老婆对象个数
    画出内存图
'''


class Wife:
    count = 0

    @classmethod
    def count01(cls):
        print(Wife.count)

        # 数据成员

    def __init__(self, name, sex):
        # self 是调用当前方法的对象地址
        self.name = name
        self.sex = sex
        Wife.count += 1


wife01 = Wife("莉莉", "女")
wife02 = Wife("雪雪", "女")
Wife.count01()
