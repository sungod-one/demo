'''
    计算一个字符串中的字符以及出现的次数
    abcdefce
    a 1
    b 1
    c 2
    d 1
    e 2
    f 1
'''
str_input = input("请输入一个字符串：")
dict_str = {}
for letter in str_input:
    if letter not in dict_str:
        dict_str[letter] = 1
    else:
        dict_str[letter] += 1
for str1, count in dict_str.items():
    print(str1, count)
# b = str_input.count("a")
# print(b)


str_input = input("请输入一个字符串：")
dict_str = {}
for letter in str_input:
    if letter not in dict_str:
        dict_str[letter] = str_input.count(letter)
for str1, count in dict_str.items():
    print(str1, count)


set1 = {item for item in str_input}
for item in set1:
    print('{}的个数为：{}'.format(item, str_input.count(item)))


