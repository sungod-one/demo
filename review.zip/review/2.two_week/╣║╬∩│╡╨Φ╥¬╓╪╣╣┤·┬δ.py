def goods_select(goods_info):
    """
    选择商品
    :return: 商品价格和商品数量的元组
    """
    for number, info in goods_info.items():
        print("编号：%d,名称：%s，单价：%d。" % (number, info["name"], info["price"]))
    while True:
        goods_number = int(input("请输入商品编号："))
        if goods_number in goods_info:
            goods_count = int(input("请输入商品数量："))
            return (goods_info[goods_number]["name"], goods_info[goods_number]["price"], goods_count)
        else:
            print("没有该商品。")


def shopping_cart(name, price, count, current_amount):
    """
    购物车
    :param price: 商品价格
    :param count: 商品数量
    :param current_amount: 存放此次加入购物车金额的列表
    :return: 返回加入此次金额的列表
    """
    print("加入购物车成功")
    current_amount[name] = {"price": price, "count": count}
    return current_amount


def place_order(current_amount):
    """
    下单结算
    :param current_amount: 每次加入购物车金额的列表
    """
    while True:
        sum01 = 0
        for name, value in current_amount.items():
            print("您的商品：%s，购买数量%d，单价%d" % (name, value["count"], value["price"]))
            sum01 += value["count"] * value["price"]
        input_money = int(input("总价%d元，请输入金额：" % sum01))
        if input_money >= sum01:
            print("购买成功，找回：%d元。" % (input_money - sum01))
            current_amount.clear()
            break
        else:
            print("金额不足")


if __name__ == '__main__':
    goods_info = {
        101: {"name": "屠龙刀", "price": 10000},
        102: {"name": "倚天剑", "price": 10000},
        103: {"name": "九阴白骨爪", "price": 8000},
        104: {"name": "九阳神功", "price": 9000},
        105: {"name": "降龙十八掌", "price": 8000},
        106: {"name": "乾坤大挪移", "price": 10000}
    }
    current_amount = {}
    while True:
        item = int(input("1键购买，2键结算。"))
        if item == 1:
            name, price, count = goods_select(goods_info)
            shopping_cart(name, price, count, current_amount)
        elif item == 2:
            place_order(current_amount)
        else:
            print("输入有误")
