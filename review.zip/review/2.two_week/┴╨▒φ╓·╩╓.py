'''
1.三和一
2.练习独立完成
3.
    在二维列表中获取13位置，向左两个元素
    在二维列表中获取22位置，向上两个元素
    在二维列表中获取03位置，向下两个元素
4.定义敌人类
        -- 数据：姓名 血量 基础攻击力 防御力
        -- 行为：打印个人信息
        创建敌人列表（至少4个元素），并画出内存图
        查找姓名是“灭霸”的敌人对象
        查找所有死人的敌人
        计算所有敌人的平均攻击力
        删除防御力小于10的敌人
        将所有敌人攻击力增加50
'''
list01 = [
    ["00", "01", "02", "03"],
    ["10", "11", "12", "13"],
    ["20", "21", "22", "23"],

]


class Vector2:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    @staticmethod
    def left():
        return Vector2(0, -1)

    @staticmethod
    def right():
        return Vector2(0, 1)

    @staticmethod
    def up():
        return Vector2(-1, 0)

    @staticmethod
    def down():
        return Vector2(1, 0)


class DoublelistHelper:

    @staticmethod
    def get_elements(double_list, vector_pos, vector_dir, count):
        list_result = []
        for item in range(count):
            vector_pos.x += vector_dir.x
            vector_pos.y += vector_dir.y
            list_result.append(double_list[vector_pos.x][vector_pos.y])
        return list_result


re = DoublelistHelper().get_elements(list01, Vector2(0, 3), Vector2.down(), 2)
print(re)

'''4.定义敌人类
        -- 数据：姓名 血量 基础攻击力 防御力
        -- 行为：打印个人信息
        创建敌人列表（至少4个元素），并画出内存图
        查找姓名是“灭霸”的敌人对象
        查找所有死人的敌人
        计算所有敌人的平均攻击力
        删除防御力小于10的敌人
        将所有敌人攻击力增加50
'''


class Enemy:
    def __init__(self, name, blood_value, attack, defense):
        self.name = name
        self.blood_value = blood_value
        self.attack = attack
        self.defense = defense

    def print_self_info(self):
        print("%s的血量为%d，攻击力为%d，防御力为%d" % (self.name, self.blood_value, self.attack, self.defense))


list02 = [
    Enemy("灭霸", 5000, 500, 200),
    Enemy("章鱼博士", 0, 200, 150),
    Enemy("霸王龙", 4000, 200, 5),
    Enemy("赖皮蛇", 0, 100, 2)
]


def select_meiba():
    for item in list02:
        if item.name == "灭霸":
            return item.print_self_info()


select_meiba()


def die_person():
    list_result02 = []
    for item in list02:
        if item.blood_value == 0:
            list_result02.append(item.name)
    return list_result02


result02 = die_person()
print(result02)


def aver_attack():
    aver = 0
    for item in list02:
        aver += item.attack
    return aver / len(list02)


print(aver_attack())


def delete_defen():
    for item in range(len(list02) - 1, -1, -1):
        if list02[item].defense < 10:
            del list02[item]

    return list02


print(delete_defen())


def add_attack():
    for item in list02:
        item.attack += 50
        item.print_self_info()



add_attack()
