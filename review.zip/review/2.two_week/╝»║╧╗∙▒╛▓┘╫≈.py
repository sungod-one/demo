'''
    集合
'''
# 1.创建集合
set01 = set()
# set ---> str
set01 = set("agsga")
str01 = str(set01)
print(set01)
print(set01)
list01 = list(set01)
print(list01)
str01 = ''.join(list01)
print(str01)
# 创建具有默认值的集合
set02 = {"abc", "a", "b", "a"}
print(set02)

# 2.添加元素
set02.add("qtx")
print(set02)

# 3.删除元素
set02.remove("a")
print(set02)

# 4.获取所有元素
for item in set02:
    print(item)

# 5.数学运算
# 交集
set10 = {1, 2, 3}
set11 = {2, 3, 4}
print(set10 & set11)  # {2,3}

# 并集
print(set10 | set11)  # {1,2,3,4}

# 补集
print(set10 ^ set11)  # {1,4} 两边不同
print(set10 - set11)  # 一边不同

# 子集
set12 = {1, 2}
print(set12 < set10)

# 超集
print(set10 > set12)

'''
#     固定集合
# '''
# # set01 = frozenset([1, 2, 3, 3, 5])
# # list02 = list(set01)
# print(list02)
# print(set01)
