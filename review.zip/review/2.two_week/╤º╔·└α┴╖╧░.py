# 练习：
# 1.创建学生类（姓名，年龄，成绩，性别
# 行为：在控制台中打印个人信息的方法）
# 2.在控制台中循环录入学生信息，如果名称是空字符，退出录入
# 3.在控制台中输出每个学生信息（调用打印方法）
# 4. 打印第一个学生信息

'''
练习一：在控制台中循环录入学生（姓名，年龄，成绩）
如果姓名输入空字符，则停止录入
将所有信息逐行打印出来
'''


class Student:
    def __init__(self, name, age, score, sex):
        self.name = name
        self.age = age
        self.score = score
        self.sex = sex

    def print_info(self):
        print("%s的年龄是%d,性别是%s,成绩是%d" % (self.name, self.age, self.sex, self.score))


# 列表套字典
list_stu_info = []
while True:
    stu_name = input("请输入学生姓名：")
    if stu_name is '':
        break
    stu_age = int(input("请输入学生年龄："))
    stu_score = int(input("请输入学生成绩："))
    stu_sex = input("请输入学生性别：")
    # list_stu_info.append({"name": stu_name, "age": stu_age, "score": stu_score, "sex": stu_sex})
    stu = Student(stu_name, stu_age, stu_score, stu_sex)
    list_stu_info.append(stu)

for stu in list_stu_info:
    stu.print_info()

list_stu_info[0].print_info()

# print("%s的年龄是%d,性别是%s,成绩是%d" % (
#     dict_value["stu_name"], dict_value["stu_age"], dict_value["stu_sex"], dict_value["stu_score"]))
