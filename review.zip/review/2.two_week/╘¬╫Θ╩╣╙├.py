'''
    在控制台中录入日期（年月），计算这是这一年的第几天
    例如：3月5日
    一月天数+二月天数+5
'''

str_input = input("请输入月日：")
month = int(str_input[0])
day = int(str_input[2])
month_day = (31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
temp = sum(month_day[:month-1])
print(temp+day)
