# 练习：实现自定义类的对象与数值的减法，乘法运算
class Vector1:
    def __init__(self, x):
        self.x = x

    def __str__(self):
        return "一维向量是：" + str(self.x)

    def __sub__(self, other):
        return Vector1(self.x - other)

    def __mul__(self, other):
        return Vector1(self.x * other)

    def __rsub__(self, other):
        return Vector1(self.x - other)

    def __rmul__(self, other):
        return Vector1(self.x * other)

    def __iadd__(self, other):
        self.x += other
        return self


v01 = Vector1(10)
print(v01 - 5)
print(v01 * 5)
print(20 - v01)
print(5 * v01)
v01 += 5
print(v01)

# 加法产生新对象 += 在原基础上进行修改
