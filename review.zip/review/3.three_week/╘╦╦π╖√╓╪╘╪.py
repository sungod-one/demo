'''
    运算符重载：让自定义的类进行数学运算
'''


class Vector1:
    def __init__(self, x):
        self.x = x

    def __str__(self):
        return "一维向量的分量是:" + str(self.x)

    def __add__(self, other):
        return Vector1(self.x+other)


v01 = Vector1(10)
print(v01 + 2)  # v01.__add__(2)

# 练习：实现自定义类的对象与数值的减法，乘法运算
