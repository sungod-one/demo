'''
    2048 第二次敲写代码
'''

list_merge = [2, 2, 0, 2]

map = [
    [2, 0, 0, 2],
    [4, 4, 2, 2],
    [2, 4, 0, 4],
    [0, 0, 2, 2]
]


class Game_2048:
    def __init__(self, map):
        self.map = map

    def move_zero_back(self, list_merge):
        for item in list_merge:
            if item is 0:
                list_merge.remove(item)
                list_merge.append(0)

    def add_adjacent(self, list_merge):
        self.move_zero_back(list_merge)
        for item in range(len(list_merge) - 1):
            if list_merge[item] == list_merge[item + 1]:
                list_merge[item] *= 2
                del list_merge[item + 1]
                list_merge.append(0)

    def transponse(self):
        for line in range(len(self.map)):
            for item in range(line + 1, len(self.map[line])):
                self.map[line][item], self.map[item][line] = self.map[item][line], self.map[line][item]

    def move_left(self):
        for item in self.map:
            self.add_adjacent(item)

    def move_right(self):
        for item in self.map:
            list01 = item[::-1]
            self.add_adjacent(list01)
            item[::-1] = list01

    def move_up(self):
        self.transponse()
        self.move_left()
        self.transponse()

    def move_down(self):
        self.transponse()
        self.move_right()
        self.transponse()


a = Game_2048(map)
# a.move_zero_back(list_merge)
# a.add_adjacent(list_merge)
a.move_down()
print(map)
