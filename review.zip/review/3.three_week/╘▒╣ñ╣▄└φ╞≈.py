'''
    定义员工管理器
        1.管理所有员工
        2.计算所有员工工资
    员工：
        程序员：底薪+项目分红
        销售：底薪 + 销售额*0.05
        软件测试
        要求：增加新岗位，员工管理器不变
'''


class EmployeeManager:
    def __init__(self):
        self.__employ_info_list = []

    @property
    def employ_info_list(self):
        return self.__employ_info_list

    def add_employ(self, employ_info):
        if isinstance(employ_info, Employees):
            self.__employ_info_list.append(employ_info)
        else:
            raise ValueError()

    def get_wage(self):
        sum_wage = 0
        for item in self.__employ_info_list:
            sum_wage += item.calculate_wage()
        return sum_wage


class Employees:
    def __init__(self, base_salary):
        self.base_salary = base_salary

    def calculate_wage(self):
        raise NotImplementedError()


class Programmer(Employees):
    def __init__(self, base_salary, program_bonus):
        super().__init__(base_salary)
        self.program_bonus = program_bonus

    def calculate_wage(self):
        wage = (self.base_salary + self.program_bonus)
        return wage


class Salesman(Employees):
    def __init__(self, base_salary, sales):
        super().__init__(base_salary)
        self.sales = sales

    def calculate_wage(self):
        wage = (self.base_salary + self.sales * 0.05)
        return wage


p01 = Programmer(8000, 5000)
s01 = Salesman(3500, 20000)
mange = EmployeeManager()
mange.add_employ(p01)
mange.add_employ(s01)
print(mange.get_wage())
