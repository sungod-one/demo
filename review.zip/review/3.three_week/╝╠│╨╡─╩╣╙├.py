'''
    继承 -- 方法


'''


# 多个子类在概念上一致的，所以就抽象出一个父类
# 多个子类的共性，可以提取到父类中
# 在实际开发中
# 从设计角度讲：先有子，再有父
# 从编码来讲：先有父，再有子
class Person:
    def say(self):
        print("说话")


class Student(Person):
    def study(self):
        print("学习")


class Teacher(Person):
    def teach(self):
        print("讲课")


stu01 = Student()
# 子类对象可以调用子类成员，也可以调用父类成员
stu01.study()
stu01.say()  # 父类成员

# 父类对象可以调用父类成员，不能调用子类成员
p01 = Person()
p01.say()

t01 = Teacher()
t01.teach()
t01.say()

# python 内置函数
# 1.判断对象是否属于一个类型
# “老师对象”是一个老师类型
print(isinstance(t01, Teacher))
# “老师对象”不是一个学生类型
print(isinstance(t01, Student))
# “老师对象”是一个人类型
print(isinstance(t01, Person))

# 1.判断一个类型是否属于另一个类型
# 老师类型不是一个学生类型
print(issubclass(Teacher, Student))
# 老师类型是一个人类型
print(issubclass(Teacher, Person))
# 人类型不是一个老师类型
print(issubclass(Person, Teacher))




'''
    继承 ------ 变量
'''


class Person:
    def __init__(self, name):
        self.name = name


# class Student(Person):
#     # 子类若没有构造函数，使用父类的
#     pass

class Student(Person):
    # 子类若具有构造函数，则必须先调用父类的构造函数
    def __init__(self, name, score):
        super().__init__(name)
        self.score = score


s01 = Student("张三", 100)
print(s01.name, s01.score)
p01 = Person("李四")
print(p01.name)



'''
    继承 ------ 设计（2）
'''


# 需求：老张开车去东北
# 变化：老张做飞机去东北
# 变化：老张坐火车/骑车


class Vehicle:
    '''
        交通工具，代表所有具体的交通工具
        继承：隔离子类变化，将子类的共性提取到父类中（运输）
    '''

    def transport(self, str_position):
        # 因为父类太过于抽象，所有
        pass


# 客户端代码，用交通工具
class Person:
    def __init__(self, name):
        self.name = name

    def go_to(self, vehicle, str_position):
        # 多态：调用父执行子
        # 调用的是交通工具的运输方法
        # 执行的是飞机的运输方法或汽车的运输方法
        vehicle.transport(str_position)


# ---------------------以上是架构师完成的--一下是程序员实现的------------------------
class Car(Vehicle):
    def transport(self, str_position):
        print("汽车开到", str_position)


class Airplane(Vehicle):
    def transport(self, str_position):
        print("飞机到", str_position)


p01 = Person("老张")
c01 = Car()
p01.go_to(c01, "东北")
f01 = Airplane()
p01.go_to(f01, "武汉")

