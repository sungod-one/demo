'''
3. 请用面向对象思想，描述以下场景：
    张无忌　教　赵敏　九阳神功
    赵敏　教　张无忌　化妆
    张无忌　上班　挣了　10000
    赵敏　上班　挣了　6000
    思考：变化点是数据的不同还是行为的不同。
    体会对象区分数据的不同
'''


class Person:
    def __init__(self, name):
        self.name = name

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    def teaching(self, person, skills):
        print(self.name + "教" + person.name + skills)

    def job(self, wage):
        print("%s上班挣了%d元" % (self.name, wage))


# class Skills:
#     def sun_alkaloids(self):
#         return "九阳神功"
#
#     def makeup(self):
#         return "化妆"


zwj = Person("张无忌")
zm = Person("赵敏")
zwj.teaching(zm, "九阳神功")
zm.teaching(zwj, "化妆")
zwj.job(10000)
zm.job(6000)
