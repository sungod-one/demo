
class Vector2:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    @staticmethod
    def left():
        return Vector2(0, -1)

    @staticmethod
    def right():
        return Vector2(0, 1)

    @staticmethod
    def up():
        return Vector2(-1, 0)

    @staticmethod
    def down():
        return Vector2(1, 0)


class DoublelistHelper:

    @staticmethod
    def get_elements(double_list, vector_pos, vector_dir, count):
        list_result = []
        for item in range(count):
            vector_pos.x += vector_dir.x
            vector_pos.y += vector_dir.y
            list_result.append(double_list[vector_pos.x][vector_pos.y])
        return list_result
