'''
    定义图形管理器
        1.管理所有图形
        2.提供计算所有图形总面积的方法
    具体图形：
        圆形（pi*r** 2）
        矩形（长乘宽）

    测试：
        创建1个图形对象，1个矩形对象，添加到图形管理器中
        调用图形管理器的计算面积方法，输出结果

    要求：增加新图形，不修改图形管理器的代码
    体会：面向对象三大特征
        封装 继承 多态
        面向对象设计原则
        开闭 单一 倒置
'''


class GraphicsManager:
    def __init__(self):
        self.__graphics_info_list = []

    @property
    def graphics_info_list(self):
        return self.__graphics_info_list

    def add_graphics(self, graphics_info):
        if isinstance(graphics_info, Graphic):
            # 多态：
            # 调用的是图形
            # 执行的是圆形/矩形
            self.__graphics_info_list.append(graphics_info)
        else:
            raise ValueError()

    def calculating_area(self):
        total_area = 0
        for item in self.__graphics_info_list:
            total_area += item.area()
        return total_area


class Graphic:
    def area(self):
        raise NotImplementedError()


class Round(Graphic):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return 3.14 * self.radius ** 2


class Rectangular(Graphic):
    def __init__(self, long, wide):
        self.long = long
        self.wide = wide

    def area(self):
        return self.long * self.wide


y01 = Round(5)
r01 = Rectangular(4, 4)
manger = GraphicsManager()
manger.add_graphics(y01)
manger.add_graphics(r01)
print(manger.calculating_area())
