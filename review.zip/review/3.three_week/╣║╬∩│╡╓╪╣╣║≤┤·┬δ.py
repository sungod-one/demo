'''
1.三合一
2.学生管理系统代码能看懂
3.穷尽一切手段，在互联网中搜索"封装"的相关资料看一下
  并结合课堂所讲（理论和代码），总结为面向对象答辩的内容
4.完成学生管理系统中，根据成绩升序显示的功能
5.(拓展)将面向过程的购物车，改为面向对象的购物车
'''
class Goods:
    def __init__(self, id, name, price, count=0):
        '''
            创建商品信息实例变量
        '''
        self.id = id
        self.name = name
        self.price = price
        self.count = count

    @staticmethod
    def goods_info():
        '''
            建立商城商品信息
        :return: 返回商城商品信息列表
        '''
        list_goos_info = [
            Goods(101, "屠龙刀", 10000),
            Goods(102, "倚天剑", 10000),
            Goods(103, "九阴白骨爪", 8000),
            Goods(104, "九阳神功", 9000),
            Goods(105, "降龙十八掌", 8000),
            Goods(106, "乾坤大挪移", 10000)
        ]
        return list_goos_info


class CommoditySystemController:
    def __init__(self):
        '''
            建立商城商品信息变量和购物车商品信息变量
        '''
        self.__goods_info_list = Goods.goods_info()
        self.__shop_car_list = []

    @property
    def shop_car_list(self):
        return self.__shop_car_list

    @property
    def goods_info_list(self):
        return self.__goods_info_list

    def add_shop(self, shop_id, count):
        '''
            向购物车添加商品
        :param shop_id: 商品编号
        :param count: 商品数量
        :return: 返回是否添加成功
        '''
        for item in self.__goods_info_list:
            if item.id == shop_id:
                item.count = count
                self.__shop_car_list.append(item)
                return True
        return False

    def calculate_money(self):
        '''
            计算购物车商品总金额
        :return: 商品总金额
        '''
        sum_money = 0
        for item in self.__shop_car_list:
            sum_money += item.price * item.count
        return sum_money

    def settlement(self, value):
        '''
            对购物车商品进行结算
        :param value: 支付金额
        :return: 支付差额
        '''
        sum_value = self.calculate_money()
        if value >= sum_value:
            self.__shop_car_list.clear()
            return value - sum_value
        return -1


class CommoditySystemView:
    def __init__(self):
        '''
            创建购物系统控制器变量
        '''
        self.__controller = CommoditySystemController()

    def __menu(self):
        '''
        打印菜单
        :return:
        '''
        print("1键购买，2键结算:", end="")

    def __select_menu(self):
        '''
            选择菜单
        '''
        self.__menu()
        item = int(input())
        if item == 1:
            self.__out_goods_info()
            self.__add_goods()
        elif item == 2:
            self.__settlement()
        else:
            print("输入有误！")

    def main(self):
        '''
        主函数
        '''
        while True:
            self.__select_menu()

    def __out_goods_info(self):
        '''
        输出商品信息
        '''
        for item in self.__controller.goods_info_list:
            print("编号:%d,名称:%s,价格:%d." % (item.id, item.name, item.price))

    def __add_goods(self):
        '''
            添加商品信息
        '''
        while True:
            item = int(input("请输入商品编号："))
            for i in self.__controller.goods_info_list:
                if i.id == item:
                    count = int(input("请输入商品数量:"))
                    if self.__controller.add_shop(item, count):
                        print("添加购物车成功！")
                        return
            print("商品编号不正确")

    def __settlement(self):
        '''
            结算购物车
        '''
        while True:
            if self.__controller.shop_car_list:
                price = self.print_order_info()
                difference = self.__controller.settlement(price)
                if difference >= 0:
                    print("购买成功,找回%d元" % difference)
                    break
                else:
                    print("金额不足！")
            else:
                print("目前购物车没东西")
                break

    def print_order_info(self):
        '''
        打印订单信息
        :return: 支付金额
        '''
        for item in self.__controller.shop_car_list:
            print("您的商品:%s,购买数量:%d,单价:%d" % (item.name, item.count, item.price))
        sum_money = self.__controller.calculate_money()
        price = int(input("您的总金额为%d，请输入支付金额:" % sum_money))
        return price

if __name__ == '__main__':
    shop = CommoditySystemView()
    shop.main()
