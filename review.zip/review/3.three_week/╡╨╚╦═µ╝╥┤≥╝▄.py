'''
4. 请用面向对象思想，描述以下场景：
    玩家(攻击力)攻击敌人(血量)，敌人受伤(掉血)，还可能死亡(掉装备，加分)。
    敌人(攻击力)攻击玩家，玩家(血量)受伤(掉血/碎屏),还可能死亡(游戏结束)。

    体会类区别行为的不同
'''


class Game_player:
    def __init__(self, name, atk, hp):
        self.name = name
        self.atk = atk
        self.hp = hp

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def atk(self):
        return self.__atk

    @atk.setter
    def atk(self, value):
        self.__atk = value

    @property
    def hp(self):
        return self.__hp

    @hp.setter
    def hp(self, value):
        self.__hp = value

    def attack(self, atk_target):
        print("玩家%s正在攻击%s，攻击力为%d" % (self.name, atk_target.name, self.atk))
        atk_target.injured(self.atk)

    def injured(self, value):
        print("%s受到%d点伤害，碎屏," % (self.name, value), end='')
        self.hp -= value
        self.state()

    def state(self):
        if self.hp > 0:
            print("当前还有%d血量" % (self.hp))
        else:
            print("游戏结束")


class Enemy:
    def __init__(self, name, atk, hp):
        self.name = name
        self.atk = atk
        self.hp = hp

    @property
    def name(self):
        return self.__name

    @name.setter
    def name(self, value):
        self.__name = value

    @property
    def atk(self):
        return self.__atk

    @atk.setter
    def atk(self, value):
        self.__atk = value

    @property
    def hp(self):
        return self.__hp

    @hp.setter
    def hp(self, value):
        self.__hp = value

    def attack(self, atk_target):
        print("玩家%s正在攻击%s，攻击力为%d" % (self.name, atk_target.name, self.atk))
        atk_target.injured(self.atk)

    def injured(self, value):
        print("%s受到%d点伤害," % (self.name, value),end='')
        self.hp -= value
        self.state()

    def state(self):
        if self.hp > 0:
            print("当前还有%d血量" % (self.hp))
        else:
            print("敌人被消灭，掉装备加分")


gtx = Game_player("钢铁侠", 50, 300)
mb = Enemy("灭霸", 80, 500)
gtx.attack(mb)
mb.attack(gtx)
gtx.attack(mb)
gtx.attack(mb)
gtx.attack(mb)
gtx.attack(mb)
gtx.attack(mb)
gtx.attack(mb)
gtx.attack(mb)
gtx.attack(mb)
gtx.attack(mb)
