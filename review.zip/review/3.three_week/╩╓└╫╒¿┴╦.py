'''
    手雷咋了，还可能伤害敌人/玩家的生命
                还可能伤害未知的事物（鸭子，房子）
    要求：增加了新事物，不影响手雷
    体会：继承的作用
         多态的体现
         设计的原则
            开闭原则
            单一职责
            依赖倒置
    画出设计图
'''


class Thing:
    def injure(self):
        # 对不用父类此方法的会报错
        # 如果子类不重写则报异常
        raise NotImplementedError


class HandGrenades:
    def boom(self, object):
        # 如果是受害者才执行
        if isinstance(object, Thing):
            print("爆炸", end='')
            object.injure()


class Player(Thing):
    def injure(self):
        print("玩家受伤")


class Enemy(Thing):
    def injure(self):
        print("敌人受伤")


p01 = Player()
e01 = Enemy()
h01 = HandGrenades()
h01.boom(p01)
h01.boom(e01)
