'''
    时间处理
'''
import time

# 1.获取当前时间戳（从1970年1月1日到现在经过的秒数）
print(time.time())
# 时间戳改为时间元组
print(time.localtime(1568934685))
# 2.时间元组(年，月，日，时，分，秒，一周第几天，一年第几天，夏令时)
print(time.localtime())
tuple_time = time.localtime()
# 时间元组改为时间戳
print(time.mktime(tuple_time))

for item in tuple_time:
    print(item)
# 通过类的操作获取时间
print(type(tuple_time))
print(tuple_time.tm_year)

# 时间元组 ----  str
str01_time = time.strftime("%y-%m-%d %H:%M:%S", tuple_time)
print(str01_time)

# str --- 时间元组
tuple01_time = time.strptime(str01_time, "%y-%m-%d %H:%M:%S")
print(tuple01_time)
