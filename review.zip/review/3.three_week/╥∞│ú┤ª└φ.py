'''
    异常处理
'''


def div_apple(apple_count):
    # ValuleError
    person_count = int(input("请输入人数："))
    # ZeroDivision
    result = apple_count / person_count
    print(result)


"""
try:
    # 可能出错的代码
    div_apple(10)
except:
    print("出错楼！")

print("后续逻辑")
"""

# 建议分门别类的处理
try:
    # 可能出错的代码
    div_apple(10)
except ValueError:
    print("输入人数必须是整数")
except ZeroDivisionError:
    print("输入的人数不能是0")
except Exception:
    print("未知错误")
else:
    # 如果异常不执行else语句
    print("没有出错")

# 无论异常不异常都会执行这条代码 不写出错的可以用try----finally
# try:
#     # 可能出错的代码
#     div_apple(10)
# finally:
#     print("异常不异常都执行")
# 作用：一般不能处理的错误，但是有一定要执行的代码，就定义到finally语句中
#

print("后续逻辑")
