# 数据角度
class Student:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def print_self(self):
        print(self.name, self.age)


s01 = Student("无忌哥哥", 28)
# 通过对象调用实例成员
s01.name = "张无忌"
s01.print_self()


# 属性使用的三种方法，第三种最常用，第二种只写的时候好用
# 第一种
class Student01:
    def __init__(self, name, age):
        self.name = name
        self.set_age(age)

    def get_age(self):
        return self.__age

    def set_age(self, value):
        self.__age = value


# 第二种
class Student02:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def __get_age(self):
        return self.__age

    def __set_age(self, value):
        self.__age = value

    age = property(__get_age, __set_age)


# 第三种
class Student03:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    @property
    def age(self):
        return self.__age

    @age.setter
    def age(self, value):
        self.__age = value


# 只读
class Student04:
    def __init__(self, name, age):
        self.name = name
        self.__age = age

    @property
    def age(self):
        return self.__age


# 只写
class Student05:
    def __init__(self, name, age):
        self.name = name
        self.age = age

    def __set_age(self, value):
        self.__age = value

    age = property(None, __set_age)


class Student07:
    __slots__ = ("name")

    def __init__(self, name):
        self.name = name


s07 = Student07("wj")
# s07.name = "无忌"
# print(s07.name)
s07.nmae = "无忌"
print(s07.nmae)
