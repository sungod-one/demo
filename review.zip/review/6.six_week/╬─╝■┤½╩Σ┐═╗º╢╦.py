"""
文件传输客户端
"""
from socket import *

socketfd = socket(AF_INET,SOCK_STREAM)

addrs = ("127.0.0.1",4250)
socketfd.connect(addrs)
f = open("captcha.jpg","rb")
while True:
    data = f.read(1024)
    if not data:
        break
    socketfd.send(data)

f.close()
socketfd.close()
