"""
array.py
共享内存存放一组数据
"""
from multiprocessing import Process, Array

# 创建共享内存
# shm = Array("i", [1, 2, 3, 5, 6])
# shm = Array("i", 5)  # 初始开辟五个整型空间
shm = Array("c", b"hello")  # 字节串　


def fun():
    # array 创建的共享内存是可以迭代的
    for i in shm:
        print(i)
    shm[0] = b"H"


p = Process(target=fun)
p.start()
p.join()
for j in shm:
    print(j)

print(shm.value)
