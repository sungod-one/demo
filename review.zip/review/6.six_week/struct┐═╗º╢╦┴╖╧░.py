"""
学生　客户端
"""
from socket import *
import struct

st = struct.Struct("i9sif")
sockfd = socket(AF_INET, SOCK_DGRAM)
ADDR = ("127.0.0.1", 4250)

while True:
    print("--------------------------------------")
    id = int(input("请输入ｉｄ："))
    name = input("请输入名字：")
    age = int(input("请输入年龄："))
    score = float(input("请输入成绩："))
    data = st.pack(id, name.encode(), age, score)
    sockfd.sendto(data, ADDR)
