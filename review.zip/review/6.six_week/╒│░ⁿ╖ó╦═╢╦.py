"""
粘包展示
"""
from socket import *
from time import sleep

# 创建tcp套接字
sockfd = socket(AF_INET, SOCK_STREAM)  # 默认参数就是tcp套接字

# 连接服务器
server_addr = ("127.0.0.1", 4251)  # 服务器地址
sockfd.connect(server_addr)

# 发送消息

for i in range(10):
    # sleep(0.1)
    sockfd.send(b"msg#")
