"""
粘包展示
"""
import socket
from time import sleep

# 创建ｔｃｐ套接字
sockfd = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

# 绑定地址
sockfd.bind(("0.0.0.0", 4251))

# 设置监听

sockfd.listen(5)
connfd, addr = sockfd.accept()

while True:
    # sleep(1)
    data = connfd.recv(1024)
    if not data:
        break
    print(data.decode())
