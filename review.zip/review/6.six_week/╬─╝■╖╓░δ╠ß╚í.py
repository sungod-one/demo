"""
1.将聊天室代码梳理一下
2.熟练multiprocessing模块创建进程
3.创建两个进程，分别复制一个文件的上下半部分，将复制内容放到两个新的文件里面，按字节数分文件
"""
from multiprocessing import Process
import os
import signal


def get_start(byte_num):
    with open("text", "rb") as f:
        data = f.read(byte_num // 2)
        with open("start.txt", "wb") as e:
            e.write(data)


def get_end(byte_num):
    with open("text", "rb") as f:
        f.seek(byte_num // 2, 0)
        data = f.read()
        with open("end.txt", "wb") as e:
            e.write(data)


def main():
    bytes_num = os.path.getsize("text")
    p1 = Process(target=get_start, args=(bytes_num,))
    p2 = Process(target=get_end, args=(bytes_num,))
    p1.start()
    p2.start()


if __name__ == '__main__':
    signal.signal(signal.SIGCHLD, signal.SIG_IGN)
    main()
