"""
udp_server.py udp套接字服务流程
重点代码
"""
from socket import *

# 创建套接字
sockfd = socket(AF_INET, SOCK_DGRAM)

# 绑定地址
sockfd.bind(("127.0.0.1", 4250))

# 接收，发送数据
while True:
    data, addr = sockfd.recvfrom(1024)
    print("收到消息：", data.decode(), addr)
    sockfd.sendto(b"Thanks", addr)

# 关闭套接字
sockfd.close()
