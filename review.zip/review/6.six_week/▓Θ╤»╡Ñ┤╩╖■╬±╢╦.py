"""
查询单词服务端
"""
from socket import *
sockfd = socket(AF_INET, SOCK_DGRAM)
sockfd.bind(("127.0.0.1", 4250))


def query_words(f,temp):
    for line in f:
        w = line.split(b" ")[0]
        if w > temp:
            return "没找到单词！".encode()
        elif temp == w:
            return line
    else:
        return "没找到单词！".encode()


f = open("dict.txt", "rb")
while True:
    data, addr = sockfd.recvfrom(1024)
    word_explain = query_words(f,data)
    sockfd.sendto(word_explain,addr)

f.close()
sockfd.close()