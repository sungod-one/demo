"""
httpserver v1.0
基本要求：获取来自浏览器的请求
        判断如果请求内容是 / 将index.html返回给客户端
        如果请求的是其他内容则返回404

"""
from socket import *


# 客户端处理函数
def request(connfd):
    # 获取请求将内容提取出来
    data = connfd.recv(4096)
    # 防止浏览器突然退出
    if not data:
        return
    info = data.decode().split(" ")[1]
    print(info)
    if info == "/":
        with open("index.html", "r") as f:
            html = f.read()
            response = "HTTP/1.1 200 OK\r\n"
            response += "Content-Type:text/html\r\n"
            response += "\r\n"
            response += html
    else:
        response = "HTTP/1.1 404 NOT Found\r\n"
        response += "Content-Type:text/html\r\n"
        response += "\r\n"
        response += "<h1>Sorry.....</h1>"
    connfd.send(response.encode())


# 搭建tcp网络
sockfd = socket(AF_INET, SOCK_STREAM)
sockfd.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
sockfd.bind(("0.0.0.0", 4250))
sockfd.listen(3)
while True:
    connfd, addr = sockfd.accept()
    html_1 = request(connfd)

connfd.close()
sockfd.close()
