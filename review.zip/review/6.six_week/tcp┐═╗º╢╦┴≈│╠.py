"""
tcp_client.py tcp客户端流程
重点代码
"""
from socket import *

# 创建tcp套接字
sockfd = socket(AF_INET, SOCK_STREAM)  # 默认参数就是tcp套接字

# 连接服务器
server_addr = ("127.0.0.1", 4250)  # 服务器地址
sockfd.connect(server_addr)

# 发送消息
while True:
    data = input("Msg>>")
    if not data:
        break
    sockfd.send(data.encode())  # 转换为字节串再发送
    data = sockfd.recv(1024)
    print("server:", data.decode())  # 打印接受内容

# 关闭套接字
sockfd.close()
