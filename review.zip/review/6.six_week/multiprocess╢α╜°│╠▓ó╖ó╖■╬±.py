"""
multiprocess.py 基于fork的多进程并发
重点代码
1.创建监听套接字
2.等待接收客户端请求
3.客户端连接创建新的进程处理客户端请求
4.原进程继续等待其他客户端连接
5.如果客户端退出，则销毁对应的进程
"""
from socket import *
import os
from multiprocessing import Process
import signal


def handle(c):
    while True:
        data = c.recv(1024)
        if not data:
            break
        print(data.decode())
        c.send(b"OK")
    c.close()


ADDR = ("0.0.0.0", 4250)

s = socket(AF_INET, SOCK_STREAM)
s.setsockopt(SOL_SOCKET, SO_REUSEADDR, 1)
s.bind(ADDR)
s.listen(5)
signal.signal(signal.SIGCHLD, signal.SIG_IGN)

while True:
    try:
        c, addr = s.accept()
        print("Connect from", addr)
    except KeyboardInterrupt:
        os._exit(0)
    except Exception as e:
        print(e)
        continue

    p = Process(target=handle, args=(c,))
    p.daemon = True  # 父进程结束则所有服务终止
    p.start()
