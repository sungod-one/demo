"""
死锁的产生
"""

from time import sleep
from threading import Thread, Lock


# 交易类
class Account:
    def __init__(self, _id, balance, lock):
        self.id = _id  # 用户
        self.balance = balance  # 存款
        self.lock = lock  # 锁

    # 取钱
    def withdraw(self, amount):
        self.balance -= amount

    # 存钱
    def deposit(self, amount):
        self.balance += amount

    def get_balance(self):
        return self.balance


Tom = Account("tom", 5000, Lock())
Alex = Account("Alex", 8000, Lock())


def transfer(from_, to, amount):
    if from_.lock.acquire():  # 锁住自己的账户
        from_.withdraw(amount)  # 账户减少
        sleep(0.5)
        if to.lock.acquire():  # 对方账户上锁
            to.deposit(amount)  # to账户加钱
            to.lock.release()
        from_.lock.release()
    print("%s给%s转账%d" % (from_.id, to.id, amount))


# transfer(Tom, Alex, 4000)
t1 = Thread(target=transfer, args=(Tom, Alex, 2000))
t2 = Thread(target=transfer, args=(Alex, Tom, 2000))
t1.start()
t2.start()
t1.join()
t2.join()
