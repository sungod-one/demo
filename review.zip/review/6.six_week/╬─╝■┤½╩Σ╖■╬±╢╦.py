"""
传输文件客户端
"""
from socket import *

sockfd = socket(AF_INET,SOCK_STREAM)

sockfd.bind(("127.0.0.1",4250))

sockfd.listen(5)

while True:
    try:
        socked,addr = sockfd.accept()
        print("Connect from：",addr)
    except Exception:
        print("连接失败！")
        continue

    f = open("gg.jpg","wb")
    while True:
        data = socked.recv(1024)
        if not data:
            break
        f.write(data)
    f.close()
    socked.close()

sockfd.close()


