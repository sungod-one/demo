"""
fork.py fork进程创建演示２
"""
import os
from time import sleep

print("--------------------------------------")
a = 1
pid = os.fork()
if pid < 0:
    print("Creat process failed")
elif pid == 0:
    print("This is a new process")
    print("a=", a)  # 从父进程继承空间ａ
    a = 10000  # 修改自己的ａ
else:
    sleep(1)
    print("The old process")
    print("a=", a)
print("All a->", a)  # 父子进程都执行
