"""
查询单词客户端
"""
from socket import *

ADDR = ("127.0.0.1", 4250)
sockfd = socket(AF_INET,SOCK_DGRAM)
while True:
    data = input("请输入单词：")
    if not data:
        break
    sockfd.sendto(data.encode(), ADDR)
    data, addr = sockfd.recvfrom(1024)
    print("单词解释为：", data.decode())

sockfd.close()