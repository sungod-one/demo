from multiprocessing import Process
from time import time


def count(x, y):
    c = 0
    while c < 7000000:
        x += 1
        y += 1
        c += 1

task = []
start = time()
for item in range(10):
    p = Process(target=count,args=(0, 0))
    task.append(p)
    p.start()

for line in task:
    line.join()

print("时间为：",time() - start)