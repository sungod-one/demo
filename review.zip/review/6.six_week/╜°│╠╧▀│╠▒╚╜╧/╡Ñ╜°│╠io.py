from time import time

def io():
    write()
    read()


def write():
    f = open("test.txt","w")
    for i in range(1800000):
        f.write("Hello world\n")
    f.close()


def read():
    f = open("test.txt")
    f.readlines()
    f.close()


start = time()
for item in range(10):
    io()

print("时间为：", time() - start)