from threading import Thread
from time import time


def io():
    print(999999)
    write()
    read()


def write():
    f = open("test.txt", "w")
    for i in range(1800000):
        f.write("Hello world\n")
    f.close()


def read():
    f = open("test.txt")
    f.readlines()
    f.close()


start = time()
task = []
for item in range(10):
    t = Thread(target=io)
    t.start()
    task.append(t)

for line in task:
    line.join()

print("时间为:", time() - start)