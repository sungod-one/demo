from multiprocessing import Pool
from time import time


def io():
    print(999999)
    write()
    read()


def write():
    f = open("test.txt", "w")
    for i in range(1800000):
        f.write("Hello world\n")
    f.close()


def read():
    f = open("test.txt")
    f.readlines()
    f.close()


start = time()

pool = Pool(10)

for item in range(10):
    pool.apply_async(func=io)

pool.close()
pool.join()
print("时间为：", time() - start)