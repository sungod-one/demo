from time import time


def count(x, y):
    c = 0
    while c < 7000000:
        x += 1
        y += 1
        c += 1


start = time()
for i in range(10):
    count(0, 0)

print("总时间为：", time() - start)