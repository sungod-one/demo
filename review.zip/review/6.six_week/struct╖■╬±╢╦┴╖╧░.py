"""
学生　服务端
"""
from socket import *
import struct

st = struct.Struct("i9sif")
sockfd = socket(AF_INET, SOCK_DGRAM)
sockfd.bind(("0.0.0.0", 4250))
f = open("sudent.txt", "a")
while True:
    data, addr = sockfd.recvfrom(1024)
    data_tuple = st.unpack(data)
    info = "%d %-9s %d %.1f\n" % (data_tuple[0], data_tuple[1].decode(), data_tuple[2], data_tuple[3])
    print(info)
    f.write(info)
    f.flush()
