'''
    外部嵌套作用域
'''


def fun01():
    # a是fun01函数的局部作用域
    # a也是fun02函数的外部嵌套作用域
    a = 1

    def fun02():
        b = 2
        # # 可以访问外部嵌套作用域变量
        # # print(a)
        # # 不能修改外部嵌套作用域变量
        # a = 2 # 创建了fun02的局部变量
        # print(a) #2
        nonlocal a
        a = 2
        print(a)

    fun02()
    print(a)  # 1


fun01()
