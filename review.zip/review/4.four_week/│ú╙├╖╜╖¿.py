class Enemy:
    def __init__(self, name, atk, defence, hp):
        self.name = name
        self.atk = atk
        self.defence = defence
        self.hp = hp

    def __str__(self):
        return "名字:%s,攻击力:%d,防御力:%d,血量:%d" % (self.name, self.atk, self.defence, self.hp)


list_enemy = [
    Enemy("灭霸", 500, 300, 0),
    Enemy("成昆", 5, 100, 1000),
    Enemy("玄冥二老", 8, 100, 0),
    Enemy("张三丰", 300, 200, 0),
    Enemy("周芷若", 150, 100, 1000),
]
# 1.
# 需求：获取所有死人
# 筛选器要给出筛选条件
re = filter(lambda item: item.hp == 0, list_enemy)
for item in re:
    print(item)
# 2
# 获取所有敌人的名字
# 提取列表中元素的某种属性
name = map(lambda item: item.name, list_enemy)
for item in name:
    print(item)

# 3.
# 获取血量最大的敌人
print(max(list_enemy, key=lambda item: item.hp))

# 4.最小值略

# 5.
# 排序
# list_enemy.sort(key=lambda item:item.atk)
# for item in list_enemy:
#     print(item)
#
re = sorted(list_enemy, key=lambda item: item.atk,reverse=True)
for item in re:
    print(item)
