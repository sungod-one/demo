'''
    列表助手模块
'''


class ListHelper:
    '''
    列表助手类
    '''

    @staticmethod
    def find(list_target, func_condition):
        '''
            通用的查找某个条件的所有元素方法
        :param list_target: 需要查找的列表
        :param func_condition: 需要查找的条件，函数类型
                函数名（参数） ---- bool
        :return: 需要查找的元素,生成器类型
        '''
        for item in list_target:
            if func_condition(item):
                yield item

    @staticmethod
    def find_one(list_target, func_condition):
        '''
                    通用的查找某个条件的单个元素方法
                :param list_target: 需要查找的列表
                :param func_condition: 需要查找的条件，函数类型
                        函数名（参数） ---- bool
                :return: 需要查找的元素,返回一个列表元素
                '''
        for item in list_target:
            if func_condition(item):
                return item

    @staticmethod
    def find_count(list_target, func_condition):
        count = 0
        '''
                    通用的查找某个条件的单个元素方法
                :param list_target: 需要查找的列表
                :param func_condition: 需要查找的条件，函数类型
                        函数名（参数） ---- bool
                :return: 需要查找的元素,返回一个列表元素
                '''
        for item in list_target:
            if func_condition(item):
                count += 1
        return count

    @staticmethod
    def is_same(list_target, func_condition):
        '''
                    通用的查找某个条件的单个元素方法
                :param list_target: 需要查找的列表
                :param func_condition: 需要查找的条件，函数类型
                        函数名（参数） ---- bool
                :return: 需要查找的元素,返回一个列表元素
                '''
        for item in list_target:
            if func_condition(item):
                return True
        return False

    @staticmethod
    def general_sum(list_target, func_condition):
        sum = 0
        for item in list_target:
            sum += func_condition(item)
        return sum

    # @staticmethod
    # def general_select(list_target, func_condition):
    #     temp_list = []
    #     for item in list_target:
    #         temp_list.append(func_condition(item))
    #     return temp_list

    @staticmethod
    def general_select(list_target, func_condition):
        '''
            通用筛选模块 获取敌人列表中所有敌人的名称/血量
        :param list_target: 目标列表
        :param func_condition: 函数类型变量
        :return:
        '''
        for item in list_target:
            yield (func_condition(item))

    @staticmethod
    def get_max(list_target, func_condition):
        '''
            通用挑选最大值
        :param list_target:目标列表
        :param func_condition:需要查询的条件，函数类型
        :return: 返回找到的最大值
        '''
        max_temp = list_target[0]
        for item in range(1, len(list_target)):
            if func_condition(list_target[item]) > func_condition(max_temp):
                max_temp = list_target[item]
        return max_temp

    @staticmethod
    def ascending_arrangement(list_target, func_condition):
        for line in range(len(list_target) - 1):
            for item in range(line, len(list_target)):
                if func_condition(list_target[line]) > func_condition(list_target[item]):
                    list_target[line], list_target[item] = list_target[item], list_target[line]

    @staticmethod
    def get_min(list_target, func_condition):
        '''
            通用挑选最小值
        :param list_target:目标列表
        :param func_condition:需要查询的条件，函数类型
        :return: 返回找到的最大值
        '''
        min_temp = list_target[0]
        for item in range(1, len(list_target)):
            if func_condition(list_target[item]) < func_condition(min_temp):
                min_temp = list_target[item]
        return min_temp

    @staticmethod
    def descending_arrangement(list_target, func_condition):
        '''
            根据条件降序排列
        :param list_target: 目标列表
        :param func_condition: 需要查询的条件，函数类型
        :return:
        '''
        for line in range(len(list_target) - 1):
            for item in range(line, len(list_target)):
                if func_condition(list_target[line]) < func_condition(list_target[item]):
                    list_target[line], list_target[item] = list_target[item], list_target[line]

    @staticmethod
    def delete(list_target, func_condition):
        for item in range(len(list_target) - 1, -1, -1):
            if func_condition(list_target[item]):
                del list_target[item]
