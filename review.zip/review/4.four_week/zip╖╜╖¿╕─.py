'''
    练习：定义生成器函数my_zip，实现下列现象
        将多个列表的每个元素合成一个元组
'''
list01 = ["孙悟空", "猪八戒", "唐僧", "沙僧"]
list02 = [101, 102, 104, 105, 108, 109]


# for item in zip(list01, list02):
#     print(item)


def my_zip(*args):
    min_temp = min(args, key=lambda item: len(item))
    for i in range(len(min_temp)):
        list_result = []
        for item in args:
            list_result.append(item[i])
        yield tuple(list_result)


# def my_zip(*args):
#     print(len(args))
#
#
b = my_zip(list01, list02)
for item in b:
    print(item)
