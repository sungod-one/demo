'''
    练习：定义生成器函数my_enumerate,实现下列现象
        将元素和索引合成一个元组
'''
list01 = [3, 4, 55, 6, 7]
for item in enumerate(list01):
    # (索引，元素)
    print(item)

for index, element in enumerate(list01):
    print(index, element)


def my_enumerate(iterable_target):
    for item in range(len(iterable_target)):
        yield (item, iterable_target[item])


a = my_enumerate(list01)
for item in a:
    print(item)
