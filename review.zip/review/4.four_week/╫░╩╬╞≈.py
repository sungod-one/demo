'''
    装饰器
'''

# 需求：对以下两个功能增加权限验证
# 添加功能
'''
def verity_permissions():
    print("权限验证")


# 已有功能
 
def enter_background():
    verity_permissions()
    print("进入后台")


# 已有功能
def delete_order():
    verity_permissions()
    print("删除订单")


enter_background()
delete_order()
缺点：增加新功能需要更改原有代码（违反开闭功能）
'''


def verity_permissions(func):
    def wrapper(*args, **kwargs):
        print("权限验证")
        func(*args, **kwargs)

    return wrapper


@verity_permissions
def enter_background(login_id, pwd):
    print(login_id, pwd, "进入后台")


# 已有功能
@verity_permissions
def delete_order(id):
    print("删除订单:", id)


# 缺点：每次拦截对已有功能的调用不科学
# enter_background = verity_permissions(enter_background)
# delete_order = verity_permissions(delete_order)

enter_background("crh", 123)
delete_order(101)
