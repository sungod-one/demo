'''
    lambda 匿名函数
        语法：lambda 参数列表：函数体
        常用于实际参数中
'''
from common.list_helper import ListHelper

list01 = [43, 4, 5, 5, 6, 7, 87, 14]


def condition01(target):
    return target % 2 == 0


def condition02(target):
    return target > 10


def condition03(target):
    return 10 < target < 50


for item in ListHelper.find(list01, lambda item: item % 2 == 0):
    print(item)


# 无参数函数 --- lambda
def fun01():
    return 100


a = lambda: 100
re = a()
print(re)


# 多参数函数 --- lambda
def fun02(p1, p2):
    return p1 > p2


b = lambda p1, p2: p1 > p2
re = b(1, 2)
print(re)


# 无返回值函数 --- lambda
def fun03(p1):
    print("参数是：", p1)


c = lambda p1: print("参数是：", p1)
c(100)


def fun04(func):
    func()


# fun04(lambda p1, p2: p1 > p2)
# fun04(lambda p1: print("参数是：", p1))

# 方法体只能有一条语句，且不能是赋值语句






# def fun05(p1):
#     p1 = 2
# lambda p1: p1 = 2
