'''
    在不改变原有功能情况下
    为其增加新功能（打印函数执行时间）
'''
import time


def print_runtime(func):
    def wrapper(*args, **kwargs):
        start = time.time()
        func(*args, **kwargs)
        print("函数运行时间为：", time.time() - start)
    return wrapper

@print_runtime
def fun01():
    time.sleep(2)
    print("fun01执行完毕喽")

@print_runtime
def fun02(a):
    time.sleep(1)
    print("fun02执行完毕喽,参数是：", a)


fun01()
fun02(100)
