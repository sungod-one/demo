'''
    迭代器 --- yield
    yield --- 生成器
'''

"""
# 生成器原理
class MyGenerator:
    # 生成器 = 可迭代对象 + 迭代器
    def __init__(self,stop_value):
        self.begin = 0
        self.stop_value = stop_value

    def __iter__(self):
        return self

    def __next__(self):
        if self.begin >= self.stop_value:
            raise StopIteration
        temp = self.begin
        self.begin+=1
        return temp
"""


def my_range(stop_value):
    number = 0
    while number < stop_value:
        yield number
        number += 1


my01 = my_range(10)
for item in my01:
    print(item)
