'''
    迭代器 --- yeild
'''


class MyRange:
    def __init__(self, number):
        self.number = number

    def __iter__(self):
        number = 0
        while number < self.number:
            # yield 作用：将下列代码改为迭代器模式
            # 生成迭代器代码的大致规则
            # 1.将yield以前的语句定义在next方法中
            # 2.将yield后面的数据作为next方法的返回值
            yield number
            number += 1


for item in MyRange(10):
    print(item)

m01 = MyRange(10)
iterator = m01.__iter__()
while True:
    try:
        item = iterator.__next__()
        print(item)
    except StopIteration:
        break
