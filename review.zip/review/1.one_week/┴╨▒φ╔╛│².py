'''
在列表中【9,25,12,8】
删除大于十的数字
'''
list01 = [9, 25, 12, 8]
a = 0
b = len(list01)
while a < b:
    if list01[a] > 10:
        del list01[a]
        a -= 1
        b -= 1
    a += 1
print(list01)

list01 = [9, 25, 12, 8]
for item in range(len(list01) - 1, -1, -1):
    if list01[item] > 10:
        del list01[item]
print(list01)
