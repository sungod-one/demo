'''
    练习：一张纸的厚度是0.01毫米
        请计算对折多少次，超过珠穆拉玛锋8844.43米
'''
paper_tick = 0.00001
count = 0
while paper_tick < 8844.43:
    paper_tick *= 2
    count += 1
print(count)
