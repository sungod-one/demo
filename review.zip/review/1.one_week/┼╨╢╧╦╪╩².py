'''
    在控制台中获取一个整数，判断是否为素数
    素数：只能被一和自身整除的正数
'''
input_number = int(input("请输入一个数："))
for item in range(2, input_number):
    if input_number % item == 0:
        print("%d不是素数" % input_number)
        break
else:
    print("%d是素数" % input_number)
