'''
列表
'''
# 1.创建列表
# 空
list01 = []
list02 = list()
# 默认值
list01 = ["悟空", 100, True]
list02 = list("我是齐天大圣")

# 2.获取元素
# 索引
print(list02[2])

# 切片
print(list02[2:])

# 3.添加元素
# append 追加（在末尾添加）
list02.append("八戒")
print(list02)
# insert 插入（指定位置添加）
list02.insert(1, True)  # 在索引为一的位置添加
print(list02)

# 4.删除元素
# 根据元素删除
list02.remove("是")
print(list02)
# 根据位置删除
del list02[0]
print(list02)

# 5.定位元素，可以增删改查
# 切片
del list02[1:3]  # 切片删除
print(list02)
list02[1:3] = ["a", "b"]
list02[1:3] = [1, 2, 3, 4, 5, 6]
list02[1:3] = []
print(list02)

# 遍历列表
# 获取列表中所有的元素
for item in list02:
    print(item)
# 倒序获取所有的元素
# 不建议
# 通过切片拿元素会重新创建新列表 不建议 list02[::-1] 想当于创建一个新列表
for item in list02[::-1]:
    print(item)

# 0 1 2 3
# 3 2 1 0
# 拿元素最好通过索引拿出来
for item in range(len(list02) - 1, -1, -1):
    print(list02[item])

for item in range(-1, -(len(list02)+1), -1):
    print(list02[item])
