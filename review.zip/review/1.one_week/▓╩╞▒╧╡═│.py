'''
day05 作业：
1. 三合一
2. 当前练习独立完成.
3. 计算列表中最小值(不使用min)．
4. 彩票　双色球：
红球:6个，1 -- 33 之间的整数   不能重复
蓝球:1个，1 -- 16 之间的整数
(1) 随机产生一注彩票[6个红球１个蓝球].
(2) 在控制台中购买一注彩票
提示：
    "请输入第1个红球号码："
    "请输入第2个红球号码："
    "号码不在范围内"
    "号码已经重复"
    "请输入蓝球号码："
5. 阅读python入门到实践第３章和第４章
      程序员的数学第四章

'''
import random

list01 = []
page = 0
while page < 6:
    number_input = random.randint(1, 33)
    if number_input not in list01:
        list01.append(number_input)
        page += 1
list01.append(random.randint(1, 16))
print(list01)

list02 = []
item = 1
while True:
    if item == 7:
        break
    num_temp = int(input("请输入第%d个红球号码：" % item))
    if num_temp > 33 or num_temp < 1:
        print("号码不在范围内")
    elif num_temp not in list02:
        list02.append(num_temp)
        item += 1
    else:
        print("号码已经重复")
while True:
    temp = int(input("请输入篮球号码："))
    if temp > 16 or temp < 1:
        print("号码不在范围内")
    else:
        list02.append(temp)
        break
print(list02)
