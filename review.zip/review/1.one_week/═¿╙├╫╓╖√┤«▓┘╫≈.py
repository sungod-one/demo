'''
    通用操作

'''
str01 = '悟空'
str02 = '八戒'
# 字符串拼接
str03 = str01 + str02
# 字符串累加
str01 += str02
print(str01)

print(str02 * 5)
str02 *= 5
print(str02)

print("悟空" > "八戒")
print("齐天大圣" in "我叫齐天大圣")
print("齐大圣" in "我叫齐天大圣")

# 索引
message = "我叫齐天大圣"
print(message[-1])
# 切片
print(message[0:2])  # 我叫
# 开始值默认为开头
print(message[:2])  # 我叫
# 结束值默认为末尾
print(message[-2:])  # 大圣

# 大天齐
print(message[-2:-5:-1])  # 大天齐
print(message[::-1])  # 圣大天齐叫我

print(message[1:1])  # 空
print(message[3:1])  # 空
print(message[-2:1])  # 空
# print(message[7])  # 索引不能越界
print(message[1:7])  # 切片越界不报错

