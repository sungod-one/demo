'''
    最多猜3次，如果猜对提示“猜对了，猜了几次”
    如果超过了，输出游戏结束
'''
import random

random_number = random.randint(0, 100)
count = 0
while count < 3:
    # 三次以内
    count += 1
    guess_value = int(input("请输入猜的数字（0-100）："))
    if guess_value == random_number:
        print("你猜对了,猜了" + str(count) + "次")
        break  # 退出循环体，不会执行else语句
    elif guess_value > random_number:
        print("猜大了")
    else:
        print("猜小了")
else:  # while 的条件不满足才会执行
    # 三次以外
    print("游戏失败")
