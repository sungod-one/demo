'''
累加10--50之间个位不是2,5,9的整数
'''
# sum_value = 0
# # for item in range(10, 51):
# #     if item % 10 in (2, 5, 9):
# #         continue
# #     sum_value += item
# # print(sum_value)

sum_value = 0
for item in range(10, 51):
    if item % 10 not in (2, 5, 9):
        sum_value += item
print(sum_value)