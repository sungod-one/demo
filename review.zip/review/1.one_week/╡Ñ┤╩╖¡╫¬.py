'''
英文单词翻转
'''
# "How are you" ---》 ”you are How“
str01 = "How are you"
list01 = str01.split(" ")
list01 = list01[::-1]
str01 = ' '.join(list01)
print(str01)

"""
"以什么东西连接".join(可迭代对象) 可迭代对象里面的内容要为字符串类型
对象.split("以什么进行切割") 把字符串按什么切割为列表 
"""
a = ("f", "c", "b")
b = "-".join(a)
print(b)
