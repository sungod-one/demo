'''
    随机加法考试
        随机产生两个数字（1---10）
        在控制台中获取两个数相加的结果
        如果用户输入正确的10分
        总共三套题，最后输出分数
        例如：请输入8+3=？   10 不得分
            请输入4+3=？   7   得10分
            请输入4+8=？   8   得10分
            总分是20
'''
import random
sum = 0
for item in range(0, 3):
    temp01 = random.randint(1, 10)
    temp02 = random.randint(1, 10)
    result = int(input("请输入%d+%d=?" % (temp01, temp02)))
    if result == temp01 + temp02:
        sum += 10
print("总分是：%d" % sum)
