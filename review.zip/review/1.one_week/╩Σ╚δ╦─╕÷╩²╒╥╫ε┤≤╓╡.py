'''
在控制台中分别录入4个数字
打印最大的数字
'''
number01 = float(input("请输入第一个数字："))
number02 = float(input("请输入第二个数字："))
number03 = float(input("请输入第三个数字："))
number04 = float(input("请输入第四个数字："))
temp = number01
if number02 > temp:
    temp = number02
if number03 > temp:
    temp = number03
if number04 > temp:
    temp = number04
print(temp)
