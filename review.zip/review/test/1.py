class Solution:
    def Sum_Solution(self, n):
        return n and self.Sum_Solution(n - 1) + n


a = Solution()

b = a.Sum_Solution(100)
print(b)