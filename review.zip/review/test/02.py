# def quick(target_list):
#     if len(target_list) < 1:
#         return target_list
#     temp = target_list[len(target_list) // 2]
#     left = [item for item in target_list if item < temp]
#     middle = [item for item in target_list if item == temp]
#     right = [item for item in target_list if item > temp]
#     return quick(left) + middle + quick(right)
#
#
# list01 = [5, 2, 4, 3, 5]
# print(quick(list01))

class SigleExmple:
    def __new__(cls, *args, **kwargs):
        if not isinstance(cls, "_instance"):
            nod = super(SigleExmple, cls).__new__(cls, *args, **kwargs)
            cls._instance = nod
            return cls._instance






















