"""
快排
"""
list01 = [4, 9, 3, 1, 2, 5, 8, 4]


def sub_sort(list_, low, height):
    temp = list_[low]
    while low < height:
        while list_[height] >= temp and height > low:
            height -= 1
        list_[low] = list_[height]
        while list_[low] <= temp and height > low:
            low += 1
        list_[height] = list_[low]

    list_[low] = temp
    return low


def quick_sort(list_, low, height):
    if height > low:
        key = sub_sort(list_, low, height)
        quick_sort(list_, low, key - 1)
        quick_sort(list_, key + 1, height)


quick_sort(list01, 0, len(list01) - 1)
print(list01)
