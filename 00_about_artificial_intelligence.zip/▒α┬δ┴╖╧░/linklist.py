"""
linklist.py
功能：实现单链表的构建和功能操作
重点代码
init_list 初始化链表
show 返回每个元素
is_empty 判断链表是否为空
clear 清空链表
append 尾部插入
head_insert 头部插入
insert 指定位置插入
len 链表长度
delete 删除链表元素按索引
remove 删除元素按值
get_index 根据索引获取元素值
generator 迭代链表对象
"""


class Node:
    def __init__(self, val, next=None):
        self.val = val
        self.next = next


class LinkList:
    def __init__(self):
        self.head = Node(None)

    def init_list(self, list_):
        temp = self.head
        for item in list_:
            temp.next = Node(item)
            temp = temp.next

    def show(self):
        temp = self.head
        while temp.next:
            temp = temp.next
            print(temp.val)

    def is_empty(self):
        return self.head.next is None

    def clear(self):
        self.head.next = None

    def append(self, value):
        temp = self.head
        while temp.next:
            temp = temp.next
        temp.next = Node(value)

    def head_insert(self, value):
        temp = self.head.next
        self.head.next = Node(value)
        self.head.next.next = temp

    def insert(self, index, value):
        temp = self.head
        for item in range(index):
            if temp.next is None:
                break
            temp = temp.next
        local = temp.next
        temp.next = Node(value)
        temp.next.next = local

    def delete(self, index):
        temp = self.head
        for item in range(index):
            if temp.next.next is None:
                raise IndexError("index out of range")
            temp = temp.next
        temp.next = temp.next.next

    def remove(self, value):
        temp = self.head
        while temp.next:
            if temp.next.val == value:
                break
            temp = temp.next
        else:
            raise ValueError("val not in linklist")
        temp.next = temp.next.next

    def get_index(self, index):
        temp = self.head
        for item in range(index):
            if temp.next.next is None:
                raise IndexError("index out of range")
            temp = temp.next
        return temp.next.val

    def generator(self):
        temp = self.head.next
        while temp:
            yield temp.val
            temp = temp.next

    def __iter__(self):
        temp = self.head.next
        while temp:
            yield temp.val
            temp = temp.next



if __name__ == '__main__':
    a = LinkList()
    a.init_list([1, 2, 3, 9, 8, 6])
    a.insert(6, 100)

    for item in a:
        print(item)
