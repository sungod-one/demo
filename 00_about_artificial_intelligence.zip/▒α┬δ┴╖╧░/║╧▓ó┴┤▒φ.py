'''

作业： 1.  对链表进行画图整理
       2.  创建两个链表，两个链表中的值均为有序值
			将连个链表合并为一个，合并后要求值仍为有序值

'''
from linklist import *

link01 = LinkList()
link01.init_list([1, 2, 4, 5, 8, 9, 14])
link02 = LinkList()
link02.init_list([1, 5, 6, 10, 13])


def merge(l1, l2):
    p = l1.head
    q = l2.head.next
    while p.next:
        if q.val >= p.next.val:
            p = p.next
        else:
            temp = p.next
            p.next = q
            q = temp
    p.next = q


merge(link01, link02)
link01.show()
