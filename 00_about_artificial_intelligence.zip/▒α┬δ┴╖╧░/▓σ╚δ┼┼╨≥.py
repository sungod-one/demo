"""
插入排序
"""
list01 = [4, 9, 3, 1, 2, 5, 8, 4]


def insert_sort(list_):
    for item in range(1, len(list_)):
        temp = list_[item]
        for line in range(item - 1, -1, -1):
            if list_[line] >= temp:
                list_[line + 1] = list_[line]
            else:
                list_[line + 1] = temp
                break
        else:
            list_[0] = temp



insert_sort(list01)
print(list01)
