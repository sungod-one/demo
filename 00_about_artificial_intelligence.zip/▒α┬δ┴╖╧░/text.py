for item in range(4):
    print(item)
    if item == 4:
        break
else:
    print("你好")