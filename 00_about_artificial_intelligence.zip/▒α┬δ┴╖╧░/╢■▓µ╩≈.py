"""
二叉树
"""


class Node:
    def __init__(self, val, left=None, right=None):
        self.val = val
        self.left = left
        self.right = right


class Tree:
    def __init__(self, root):
        self.root = root

    def preOrder(self, node):
        if node is None:
            return
        print(node.val, end=" ")
        self.preOrder(node.left)
        self.preOrder(node.right)

    def inOrder(self, node):
        if node is None:
            return
        self.preOrder(node.left)
        print(node.val, end=" ")
        self.preOrder(node.right)

    def postOrder(self, node):
        if node is None:
            return
        self.preOrder(node.left)
        self.preOrder(node.right)
        print(node.val, end=" ")

    def levelOrder(self, node):
        pass


if __name__ == '__main__':
    b = Node('B')
    f = Node('F')
    g = Node('G')
    d = Node('D', f, g)
    i = Node('I')
    h = Node('H')
    e = Node('E', i, h)
    c = Node('C', d, e)
    a = Node('A', b, c)  # 树根
    tree = Tree(a)
    tree.preOrder(a)
